#' prada: A package accompanying the course "practical data analysis" (hence pra-da) and the book "stastisics_21"
#'
#' The package contains some conveniecne functions and the data used in the aforementioned course and book


#' @docType package
#' @name prada
NULL