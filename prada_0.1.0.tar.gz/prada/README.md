# prada
Accompagnying R package for the course "Praktische Datenanalyse" (practical data analysis) and the book "Statistik_21"
